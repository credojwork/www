<div class="wrap load_fm_extensions">
<?php echo $file = file_get_contents('https://webdesi9.com/extensions/', FILE_USE_INCLUDE_PATH); ?>
</div>